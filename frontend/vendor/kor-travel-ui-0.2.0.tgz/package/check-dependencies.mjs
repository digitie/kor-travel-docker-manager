// SPDX-FileCopyrightText: 2026 Youn-sok Choi (digitie)
// SPDX-License-Identifier: GPL-3.0-or-later
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { createHash } from "node:crypto";
import { parseArgs } from "node:util";
const { values } = parseArgs({ options: { package: { type: "string", default: "package.json" }, lock: { type: "string", default: "package-lock.json" }, workspace: { type: "string", default: "" }, artifacts: { type: "string" }, source: { type: "string", multiple: true, default: [] } } });
const read = p => JSON.parse(readFileSync(p, "utf8"));
const policy = read(new URL("./dependency-policy.json", import.meta.url));
const packagePath = resolve(values.package), lockPath = resolve(values.lock);
const manifest = read(packagePath), lock = read(lockPath), errors = [];
const deps = { ...manifest.dependencies, ...manifest.devDependencies };
for (const name of policy.required) if (!(name in deps)) errors.push(name + ": 필수 직접 의존성 없음");
for (const name of policy.forbidden) if (name in deps) errors.push(name + ": 공통 Radix 구현으로 이관 필요");
function installed(name) {
 const parts = values.workspace.split("/").filter(Boolean);
 for (let i=parts.length;i>=0;i--) {
  const key = [...parts.slice(0,i), "node_modules",name].join("/");
  if (lock.packages?.[key]) return lock.packages[key];
 }
 return undefined;
}
for (const [name, spec] of Object.entries(deps)) {
 const wanted = policy.versions[name];
 if (!wanted) continue;
 if (policy.artifactPackages.includes(name)) {
  if (spec !== "file:vendor/" + (name.startsWith("@") ? name.slice(1).replace("/", "-") : name) + "-" + wanted + ".tgz") errors.push(name + ": 공통 vendor 산출물 참조 불일치");
 } else if (spec !== wanted) errors.push(name + ": 선언 " + spec + " != " + wanted);
 const got = installed(name);
 if (got?.version !== wanted) errors.push(name + ": lock 설치 버전 " + got?.version + " != " + wanted);
}
// 체크인한 산출물 원장은 실제 bytes와 lock integrity를 함께 검증한다.
if (!values.artifacts) errors.push("--artifacts 공통 산출물 원장이 필요함");
else {
 const artifacts = read(resolve(values.artifacts));
 for (const name of ["@kor-travel/ui","@kor-travel/tokens","vworld-map-web","vworld-map-core"]) {
  if (!(name in deps)) continue;
  const artifact = artifacts.packages?.[name], spec = deps[name];
  if (!artifact?.integrity || !spec.startsWith("file:")) { errors.push(name + ": 산출물 무결성 원장 누락"); continue; }
  const path = resolve(dirname(packagePath), spec.slice(5));
  if (!existsSync(path)) { errors.push(name + ": 산출물 파일 없음"); continue; }
  const actual = "sha512-" + createHash("sha512").update(readFileSync(path)).digest("base64");
  if (artifact.integrity !== actual || installed(name)?.integrity !== actual) errors.push(name + ": 파일·원장·lock 해시 불일치");
 }
}
function scan(path) {
 if (!existsSync(path)) { errors.push(path + ": 검사할 소스 경로 없음"); return; }
 for (const entry of readdirSync(path, { withFileTypes: true })) {
  if (["node_modules", ".next", "test", "tests", "e2e"].includes(entry.name)) continue;
  const file = resolve(path, entry.name);
  if (entry.isDirectory()) scan(file);
  else if (/\.[jt]sx?$/.test(entry.name) && !/\.(test|spec)\./.test(entry.name)) {
   const text = readFileSync(file, "utf8");
   if (/<(?:table|Table)(?:\s|>)/.test(text)) errors.push(file + ": 공통 VirtualTable 외 표 구현");
   if (/from\s+["'](?:@base-ui\/react|@floating-ui\/)/.test(text)) errors.push(file + ": 공통 Radix 외 overlay 구현");
  }
 }
}
for (const path of values.source) scan(resolve(path));
if (errors.length) { console.error(errors.join("\n")); process.exitCode = 1; }
else console.log("공통 의존성과 산출물 일치");
