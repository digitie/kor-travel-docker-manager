# Reproducing the patched FocusScope package

This is an unreleased downstream source fix, not an official Radix release.
The public fork/PR records the source commit below; the upstream and full source hashes are in PROVENANCE.json.

Source commit: 1752a539c8d5ae57961a0fa2702d2573d48fefe7
Upstream: https://github.com/radix-ui/primitives/tree/eb3a2b7091293e27df8f9ba906632d8daa3d81a3

Use Node 24.22.2 and pnpm 11.5.0 in the full source checkout:

    pnpm install --frozen-lockfile
    pnpm --filter @radix-ui/react-focus-scope... build
    pnpm exec vitest run packages/react/focus-scope
    pnpm exec playwright test e2e/focus-scope.spec.ts
    node scripts/create-focus-scope-fix.mjs /tmp/radix-focus-scope-artifacts

Normal consumers keep their common/Radix imports. Only the central dependency policy selects this exact engine tarball.
